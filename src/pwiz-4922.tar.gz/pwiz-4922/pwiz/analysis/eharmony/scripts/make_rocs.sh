#!/bin/bash
rm roc.txt

python python/new_roc.py ${1} 1
python python/new_roc.py ${1} 0.90
python python/new_roc.py ${1} 0.80
python python/new_roc.py ${1} 0.70
python python/new_roc.py ${1} 0.60
python python/new_roc.py ${1} 0.50
python python/new_roc.py ${1} 0.40
python python/new_roc.py ${1} 0.40
python python/new_roc.py ${1} 0.35
python python/new_roc.py ${1} 0.30
python python/new_roc.py ${1} 0.25
python python/new_roc.py ${1} 0.23
python python/new_roc.py ${1} 0.21
python python/new_roc.py ${1} 0.20
python python/new_roc.py ${1} 0.17
python python/new_roc.py ${1} 0.15
python python/new_roc.py ${1} 0.10
python python/new_roc.py ${1} 0.05
python python/new_roc.py ${1} 0.04
python python/new_roc.py ${1} 0.03
python python/new_roc.py ${1} 0.02
python python/new_roc.py ${1} 0.01
python python/new_roc.py ${1} 0.001
python python/new_roc.py ${1} 0.0008
python python/new_roc.py ${1} 0.0005
python python/new_roc.py ${1} 0.0003
python python/new_roc.py ${1} 0.00001
python python/new_roc.py ${1} 0.0