
#include <iostream>

int main()
{
    std::cout << "int foo;\n";
    return 0;
}

