Copyright 2004 Vladimir Prus
Distributed under the Boost Software License, Version 1.0.
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt)


This example shows how user can create his own build variants. Two variants are
defined: "crazy", which is just a random combination of properties, and
"super-release", which is inherited from "release", and differs by a single
define.

See the jamroot.jam for the definitions.
