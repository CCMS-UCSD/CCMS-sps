Copyright 2003 Vladimir Prus 
Distributed under the Boost Software License, Version 1.0. 
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt) 


This example show how to add a new target type and a new tool support to
Boost.Build. Please refer to extender manual for a complete description of this
example.

Note that this example requires Python. If cygwin Python on Windows is to be
used, please go to "verbatim.jam" and follow instructions there.
